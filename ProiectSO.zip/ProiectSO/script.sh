if ! test $# -eq 1
then
    echo "Eroare: nu a primit un singur argument!"
    exit 1
fi

count=0

while read linie
do
    v=`echo $linie | grep -e '^[A-Z][a-zA-Z0-9, ]*[\.!?]$' | grep -v ', si' | grep -e $1`
    if test -n "$v"
    then
        count=`expr $count + 1`
    fi
done

echo $count
